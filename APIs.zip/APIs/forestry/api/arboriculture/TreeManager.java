package forestry.api.arboriculture;

public class TreeManager {
	public static int treeSpeciesCount = 0;
	
	/**
	 * Get your own reference to this via AlleleManager.alleleRegistry.getSpeciesRoot("rootTrees") and save it somewhere.
	 */
	@Deprecated
	public static ITreeRoot treeInterface;
}
