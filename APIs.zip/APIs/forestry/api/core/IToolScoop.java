package forestry.api.core;

/**
 * Marks a tool as a scoop. 
 */
public interface IToolScoop {

}
