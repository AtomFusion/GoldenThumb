package forestry.api.food;

public class BeverageManager {
	public static IBeverageEffect[] effectList = new IBeverageEffect[128];

	public static IInfuserManager infuserManager;
	public static IIngredientManager ingredientManager;
}
