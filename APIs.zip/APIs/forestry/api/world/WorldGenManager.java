package forestry.api.world;

public class WorldGenManager {
	public static IWorldGenInterface worldgenInterface;
}
