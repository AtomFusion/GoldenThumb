package forestry.api.circuits;

public interface ICircuitLayout {

	String getUID();

	String getName();

	String getUsage();

}
